Atomic Orbital fonts

Space Grotesk (headings): desktop TTFs in this folder, SIL Open Font License (OFL.txt).
IBM Plex Sans (body) and IBM Plex Mono (figures): free from Google Fonts or IBM, SIL Open Font License.
  https://fonts.google.com/specimen/IBM+Plex+Sans
  https://fonts.google.com/specimen/IBM+Plex+Mono
  https://github.com/IBM/plex
web/ holds the Latin web fonts the Nucleus and website use.
